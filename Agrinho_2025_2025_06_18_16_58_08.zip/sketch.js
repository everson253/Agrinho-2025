let trees = [];
let maxTrees = 50; // Número máximo de árvores
let growSpeed = 0.5; // Velocidade de crescimento das árvores

function setup() {
  createCanvas(800, 600);
  // Inicialmente, nenhuma árvore
}

function draw() {
  background(220, 255, 200); // Cor de fundo que lembra natureza

  // Adiciona novas árvores até atingir o máximo
  if (trees.length < maxTrees) {
    if (random(1) < 0.02) { // Chance de nascer uma nova árvore
      trees.push(new Tree());
    }
  }

  // Desenha e faz crescer as árvores existentes
  for (let tree of trees) {
    tree.grow();
    tree.display();
  }
}

// Classe que representa uma árvore
class Tree {
  constructor() {
    this.x = random(width);
    this.y = height;
    this.height = 0; // altura inicial
    this.maxHeight = random(50, 150);
    this.branches = [];
    this.hasGrown = false;
  }

  grow() {
    if (this.height < this.maxHeight) {
      this.height += growSpeed;
    } else {
      this.hasGrown = true;
    }
  }

  display() {
    stroke(34,139,34);
    strokeWeight(4);
    // Desenha o tronco
    line(this.x, this.y, this.x, this.y - this.height);

    // Desenha folhas quando a árvore estiver crescida
    if (this.hasGrown) {
      fill(34,139,34, 150);
      noStroke();
      ellipse(this.x, this.y - this.height, 20, 20);
    }
  }
}
